//store the products array in localstorage as "data"
